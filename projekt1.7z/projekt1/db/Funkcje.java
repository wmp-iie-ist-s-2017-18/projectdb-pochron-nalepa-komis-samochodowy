package projekt1.db;

import java.sql.Connection;
import java.sql.Statement;

/**
 *
 * @author Wojciech
 */
public class Funkcje {

    public static boolean createTables(Connection c) {
     
        return true;
    }
    
    
    

    
}
